<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/jpeg" href="favicon.jpg"> <!--da cambiare la favicon una volta che le setterò -->
    <script src="https://kit.fontawesome.com/6473534da9.js" crossorigin="anonymous"></script>
    <title>
        <?php
        if (isset($_GET['error_type']) && $_GET['error_type'] === "registration") {
            echo "Registration Error";
        } else {
            echo "Login Error";
        }
        ?>
    </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #000000;
            margin: 0;
            padding: 0;
        }
        
        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 88vh; 
            text-align: center;
        }
        
        .error-box {
            background-color: #f9f9f9;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
            position: relative;
        }
        
        .error-icon {
            font-size: 120px;
            color: #c90c3e; 
            margin-bottom: 20px;
        }
        
        h1 {
            margin: 0 0;
            font-size: 36px;
            color: #c90c3e; 
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }
        
        p {
            margin-bottom: 14px;
            font-size: 18px;
            color: #444;
            line-height: 1.5;
        }
        
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #c90c3e; 
            color: #ffffff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-top: 10px;
        }
        
        .btn:hover {
            background-color: #8f0d30; 
        }
        
        footer {
            background-color: #000000;
            text-align: center;
            font-size: 12px;
            padding: 14px 0;
            margin-top: auto;
            width: 100%;
        }
        
        .footer-text {
            font-size: 10px;
            color: #ffffff;
        }

        footer::before {
            content: '';
            display: block;
            width: 100%;
            height: 1px;
            background-color: #444;
            margin-bottom: 10px;
        }

        .error-messages {
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-box"> 
            <i class="fab fa-android error-icon"></i>
            <h1>
                <?php
                if (isset($_GET['error_type']) && $_GET['error_type'] === "registration") {
                    echo "Registration Error";
                } else {
                    echo "Login Error";
                }
                ?>
            </h1>
            <?php
            if (isset($_GET['error'])) {
                $error_message = $_GET['error'];
            ?>
            <p><u>Ecco alcuni possibili errori:</u></p>
            <div class="error-messages">
                <?php
                $error_lines = explode("\n", $error_message);
                foreach ($error_lines as $line) {
                    echo "<p>$line</p>";
                }
                ?>
            </div>
            <?php
            }
            ?>
            <a href="./../Login/auth_index.php" class = "btn">Try Again</a>
        </div>
    </div>

    <footer>
        <p class="footer-text">Capolavoro 2024</p>
        <p class="footer-text">&copy; 2024 Toscano Luca. Tutti i diritti riservati.</p>
    </footer>
</body>
</html>
