<?php
session_start();
session_unset();
session_destroy();

/*
Ci permette di cancellare i cookie quando slogghiamo, al momento non ci serve

setcookie("remember_email", '', time() - 365*24*3600, '/');
setcookie("remember", '', time() - 365*24*3600, '/');

$servername = "localhost";
$username = "root";
$password_db = ""; 
$dbname = "my_lucss";

$conn = new mysqli($servername, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$mail = isset($_COOKIE['remember_email']) ? $_COOKIE['remember_email'] : '';
$update_query = "UPDATE form SET cookie_session = NULL WHERE mail='$mail'";
$conn->query($update_query);

$conn->close();*/


header("location: ./auth_index.php");
?>