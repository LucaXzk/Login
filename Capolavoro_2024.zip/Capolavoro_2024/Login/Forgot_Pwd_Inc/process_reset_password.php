<!DOCTYPE html>
<title>Password Update</title>
</html>
<?php
$servername = "localhost";
$username = "root";
$password_db = ""; 
$dbname = "my_lucss";

$conn = new mysqli($servername, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$token = $_POST["token"];
$token_hash = hash("sha256", $token);

$sql = "SELECT * FROM form
        WHERE reset_token_hash = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $token_hash);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Token non trovato");
}

$form = $result->fetch_assoc();

if (strtotime($form["reset_token_expires_at"]) <= time()) {
    die("Il token è scaduto");
}

$password = $_POST["password"];
$password_confirmation = $_POST["password_confirmation"];

if (strlen($password) < 8) {
    die("La password deve contenere almeno 8 caratteri");
}

if (!preg_match("/[a-z]/i", $password)) {
    die("La password deve contenere almeno una lettera");
}

if (!preg_match("/[0-9]/", $password)) {
    die("La password deve contenere almeno un numero");
}

if ($password !== $password_confirmation) {
    die("Le password non corrispondono");
}

$password_hash = password_hash($password, PASSWORD_DEFAULT);

$sql = "UPDATE form
        SET password = ?,
            reset_token_hash = NULL,
            reset_token_expires_at = NULL
        WHERE id_ut = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $password_hash, $form["id_ut"]);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Password aggiornata con successo. Ora puoi effettuare il <a href='./../auth_index.php'>login</a>.";
} else {
    echo "Impossibile aggiornare la password. Si prega di riprovare.";
}

$stmt->close();
$conn->close();
?>