<!DOCTYPE html>
    <title>Password Reset</title>
</html>
<?php
$servername = "localhost";
$username = "root";
$password_db = ""; 
$dbname = "my_lucss";

$conn = new mysqli($servername, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

if (isset($_POST["mail"])) {
    $mailAddress = $_POST["mail"];

    $token = bin2hex(random_bytes(16));
    $token_hash = hash("sha256", $token);
    $expiry = date("Y-m-d H:i:s", time() + 60 * 30);

    $sql = "UPDATE form
            SET reset_token_hash = ?,
                reset_token_expires_at = ?
            WHERE mail = ?";
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $token_hash, $expiry, $mailAddress);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        require 'vendor/autoload.php';

        $mail = new PHPMailer\PHPMailer\PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            $mail->Username = ''; //Inserire l'account mail da cui si vuole mandare il reset della pwd (es. noreply@gmail.com)
            $mail->Password = ''; //Inserire la pwd dell'account mail

            $mail->setFrom(''); //Ripetere account mail inserito precedentemente (es. noreply@gmail.com)
            $mail->addAddress($mailAddress);

            $mail->isHTML(true);
            $mail->Subject = "Password Reset";

            $mail->Body = "
                <html>
                <head>
                    <style>
                    body {
                        font-family: 'Open Sans', 'Lucida', 'Lucida Sans', 'Lucida Grande', Arial, sans-serif;
                        font-size: 15px;
                        line-height: 22px;
                        color: #918879;
                        padding: 0px 10px 10px 10px;
                    }
                        .container {
                            max-width: 600px;
                            margin: 0 auto;
                            padding: 20px;
                            background-color: #f5f5f5;
                            border-radius: 5px;
                            text-align: center;
                        }
                        .message h1 {
                            font-weight: bold;
                            font-size: 25px;
                            color: #333333;
                            text-align: center;
                        }
                        a.btn {
                            background-color: #555555;
                            color: #ffffff;
                            padding: 10px 20px;
                            border-radius: 3px;
                            text-decoration: none;
                            display: inline-block;
                            cursor: pointer;
                            transition: background-color 0.3s ease; 
                        }
                        a.btn:hover {
                            background-color: #1c7e91;
                        }
                    </style>
                </head>
                <body>
                    <div class='container'>
                    <div class='message'>
                        <h1>Password Reset</h1>
                        <p>Per reimpostare la tua password, clicca sul link qui sotto.</p>
                        <a href='http://localhost/Projects/Capolavoro_2024/Login/Forgot_Pwd_Inc/reset_password.php?token=$token' class='btn'>Reset Password</a>
                    </div>
                    </div>
                </body>
                </html>";

            $mail->send();
            echo "Email inviata con successo! Controlla la tua casella di posta.\n";
            echo "<br><br>Puoi chiudere la finestra corrente.";

        } catch (Exception $e) {
            echo "Errore nell'invio dell'email. Dettagli: {$mail->ErrorInfo}";
        }
    } else {
        echo "Nessuna email trovata nel database corrispondente a '$mailAddress'.";
    }
} else {
    echo "Indirizzo email non specificato.";
}
?>
