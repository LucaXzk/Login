<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: 'Roboto', Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa; 
        }
        .container {
            text-align: center;
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
            width: 350px;
            max-width: 80%; 
        }
        h1 {
            font-size: 28px;
            margin-bottom: 30px;
            color: #333; 
        }
        input[type="email"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 12px 24px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s ease; 
        }
        button:hover {
            background-color: #0056b3; 
        }
        a {
        color: #007bff;
        text-decoration: none; 
        transition: color 0.3s ease; 
        }

        a:hover {
            color: #ff0000;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Forgot Password?</h1>
        <form method="post" action="mailer.php">
            <input type="email" placeholder="Enter your Email" name="mail" id="mail" required>
            <button type="submit">Send</button>
        </form>
        <p style="margin-top: 20px; font-size: 14px; color: #999;">
            Errore di click? Torna alla pagina di <a href='./../auth_index.php'>Login</a>.
        </p>
    </div>
</body>
</html>
