<?php
session_start();

$servername = "localhost";
$username = "root";
$password_db = ""; 
$dbname = "my_lucss";

$error_messages = array();

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function validateDomain($email) {
    list($user, $domain) = explode('@', $email);
    return checkdnsrr($domain, 'MX');
}

$conn = new mysqli($servername, $username, $password_db, $dbname);
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
     //logica registrazione   
    if(isset($_POST['register'])) {                                                       
        $nome = $_POST["nome"];
        $cognome = $_POST["cognome"];
        $mail = $_POST["mail"];
        $password = $_POST["password"];

        /*if (!validateEmail($mail)) {                                                  //verifica se l'email non contiene @ oppure ha caratteri strani
        $error_message = "Indirizzo email non valido!";
        header("Location: ./../Error/error_index.php?error=" . urlencode($error_message));
        exit();
        }
        if (!validateDomain($mail)) {
            $error_message = "Il dominio dell'indirizzo email non esiste!";          //verifica se il dominio esiste realmente (controlla il DNS per vedere se ci sono record MX -mail exchange- associati al dominio)
            header("Location: ./../Error/error_index.php?error=" . urlencode($error_message));      
            exit();
        }*/

        $check_query = "SELECT * FROM form WHERE mail='$mail'";
        $result = $conn->query($check_query);

        if(empty($nome)) {
            $error_messages[] = "⚠️ Il campo 'Nome' è vuoto!";
        }
        if(empty($cognome)) {
            $error_messages[] = "⚠️ Il campo 'Cognome' è vuoto!";
        }
        if ($result->num_rows > 0) {
            $error_messages[] = "⚠️ Questa email è già stata registrata!";
        } else {
            if(empty($mail)) {
                $error_messages[] = "⚠️ Il campo 'Email' è vuoto!";
            } elseif (!validateEmail($mail)) {
                $error_messages[] = "⚠️ L'indirizzo email non è valido!";
            } else {
                if (!validateDomain($mail)) {
                    $error_messages[] = "⚠️ Il dominio dell'indirizzo email non esiste!";
                }
            }
        }

        /*foreach($_POST as $item) {
            if($item == '') {
                $error_message = "⚠️ Devi compilare tutti i campi!";
                if (!in_array($error_message, $error_messages)) {
                    $error_messages[] = $error_message;
                }
            }
        }*/

        if(empty($password)) {
            $error_messages[] = "⚠️ Il campo 'Password' è vuoto!";
        }

        if (!empty($error_messages)) {
            $error_type = "registration"; 
            $error_message = implode("\n", $error_messages);
            header("Location: ./../Error/error_index.php?error=" . urlencode($error_message) . "&error_type=" . $error_type);
            exit();
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_query = "INSERT INTO form (id_ut, nome, cognome, mail, password) VALUES (null, '$nome', '$cognome', '$mail', '$hashed_password')";
            if ($conn->query($insert_query) === TRUE) {
                echo "Ti sei registrato con successo! Verrai reindirizzato tra pochi secondi.";
                $_SESSION['nome'] = $nome;
                $_SESSION['cognome'] = $cognome;
                header("refresh:2;url= ./auth_index.php");
                exit();
            }
        }
    //logica login
    } elseif(isset($_POST['login'])) {                                                
        $mail = $_POST["mail"];
        $password = $_POST["password"];

        $login_query = "SELECT * FROM form WHERE mail='$mail'";
        $result = $conn->query($login_query);

        if (isset($_POST['remember'])){ 
            $expire_timestamp = time() + 30*24*3600;
            $expire_time = date('Y-m-d H:i:s', $expire_timestamp);

            $update_query = "UPDATE form SET cookie_session = NOW(), cookie_session_expires_at='$expire_time' WHERE mail='$mail'";
            $conn->query($update_query);
            setcookie("remember_email", $mail, $expire_timestamp, '/');
            setcookie("remember", true, $expire_timestamp, '/');            
        }
        else{
            setcookie("remember_email", '', time() - 365*24*3600, '/');
            setcookie("remember", '', time() - 365*24*3600, '/');
            $update_query = "UPDATE form SET cookie_session = NULL, cookie_session_expires_at = NULL WHERE mail='$mail'";
            $conn->query($update_query);
        }   

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row["password"])) {
                $_SESSION['logged_in'] = true;  
                echo "Ti sei loggato con successo";
                header("refresh:1;url= ./../Soon/logout_index.html");
                exit();
            } else {
                $error_messages[] = "⚠️ Email o password non corretta!";
            }
        } else {
            $error_messages[] = "⚠️ Utente non trovato!";
        }
        if (!empty($error_messages)) {
            $error_type = "login"; 
            $error_message = implode("\n", $error_messages);
            header("Location: ./../Error/error_index.php?error=" . urlencode($error_message) . "&error_type=" . $error_type);
            exit();
        }
    }
}

$conn->close();
?>
