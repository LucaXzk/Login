function myMenuFunction() {
var i = document.getElementById("navMenu");

if(i.className === "nav-menu") {
    i.className += " responsive";
} else {
    i.className = "nav-menu";
}
}

var a = document.getElementById("loginBtn");
var b = document.getElementById("registerBtn");
var x = document.getElementById("login");
var y = document.getElementById("register");

function login() {
    x.style.left = "4px";
    y.style.right = "-520px";
    a.className += " white-btn";
    b.className = "btn";
    x.style.opacity = 1;
    y.style.opacity = 0;
}

function register() {
    x.style.left = "-510px";
    y.style.right = "5px";
    a.className = "btn";
    b.className += " white-btn";
    x.style.opacity = 0;
    y.style.opacity = 1;
}

function showModal() {
    var modal = document.getElementById("myModal");
    modal.style.display = "block";
    
    var closeBtn = document.getElementsByClassName("close")[0];
    closeBtn.onclick = function() {
      modal.style.display = "none";
      document.body.classList.remove("modal-open");
    }
  }

  document.getElementById("register").onsubmit = function() {
    var checkBox = document.getElementById("terms-checkbox");
    if (!checkBox.checked) {
      showModal();
      return false; 
    }
    return true; 
  };
  