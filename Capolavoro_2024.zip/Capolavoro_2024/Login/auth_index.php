<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <title>Login & Registration</title>
</head>
<body>
    <nav class="nav">
        <a href="auth_index.php" class="logo">
            <img src="./images/logo.png">
            <span>Capolavoro 2024</span>
        </a>
        <?php 
        session_start();
        
        $servername = "localhost";
        $username = "root";
        $password_db = ""; 
        $dbname = "my_lucss";

        $conn = new mysqli($servername, $username, $password_db, $dbname);
        if ($conn->connect_error) {
            die("Connessione fallita: " . $conn->connect_error);
        }
        
        if (!isset($_SESSION) || session_id() == "" || session_status() === PHP_SESSION_NONE)
            session_start() 
        ?>
        <div class="nav-menu" id="navMenu">
        <ul>
            <?php 
                if (!isset($_SESSION['logged_in'])) { 
                ?>
                    <li><a href="auth_index.php" class="link active">Login</a></li>
                    </ul>
                    </div>
                    <div class="nav-button">
                        <button class="btn white-btn" id="loginBtn" onclick="login()">Sign In</button>
                        <button class="btn" id="registerBtn" onclick="register()">Sign Up</button>
                    </div>
                <?php 
                } 
            ?>
        <div class="nav-menu-btn">
            <i class="bx bx-menu" onclick="myMenuFunction()"></i>
        </div>
    </nav>
    <div class="wrapper">
<!----------------------------- Form box ----------------------------------->    
    <div class="form-box">
        <!------------------- login form -------------------------->
        <?php
        $display_email = isset($_COOKIE['remember_email']) ? $_COOKIE['remember_email'] : '';
        $checked = !empty($remember) ? "checked" : (isset($_COOKIE['remember']) ? "checked" : "");
       ?>

        <div class="login-container" id="login">
            <div class="top">
            <?php 
                //prima volta dopo che ti registri
                if (isset($_SESSION['nome']) && isset($_SESSION['cognome'])) {
                    echo "<span class='welcome-message'>Welcome " . $_SESSION['nome'] . " " . $_SESSION['cognome'] . "</span>";
                } elseif (isset($_COOKIE['remember_email'])) {      //----> controlla se ci sono cookie attivi, nel caso svolge query e prende dati utente
                    $mail = $_COOKIE['remember_email'];
                    $query = "SELECT nome, cognome FROM form WHERE mail='$mail'";
                    $result = $conn->query($query);
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        echo "<span class='welcome-message'>Welcome Back, " . $row['nome'] . " " . $row['cognome'] . "</span>";
                    } else {
                        echo "<span class='welcome-message'>Welcome Back</span>";
                    }
                } else {
                    echo "<span class='welcome-message'>Welcome Guest</span>";
                }
                ?>
                <span>Don't have an account? <a href="#" onclick="register()">Sign Up</a></span>
                <header>Login</header>
            </div>
            <form action="auth.php" method="POST">
            <input type="hidden" name="login">
            <div class="input-box">
                <input type="text" class="input-field" placeholder="Enter your Email" id="mail" name="mail" value="<?=$display_email?>">
                <i class="bx bx-user"></i>
            </div>
            <div class="input-box">
                <input type="password" class="input-field" placeholder="Password" id="password" name="password">
                <i class="bx bx-lock-alt"></i>
            </div>
            <div class="input-box">
                <input type="submit" class="submit" value="Sign In" id="Invia">
            </div>
            <div class="two-col">
            <div class="one">
                    <input type="checkbox" id="remember_me" name="remember" <?= $checked?>>
                    <label for="remember_me">Remember Me</label>
            </div>
            </form>
                <div class="two">
                    <label><a href="./Forgot_Pwd_Inc/forgot_password.php" class="forgotpwd-link">Forgot password?</a></label>
                </div>
            </div>
        </div>

        <!------------------- registration form -------------------------->
        <div class="register-container" id="register">
            <div class="top">
                <span>Have an account? <a href="#" onclick="login()">Login</a></span>
                <header>Sign Up</header>
            </div>
            <form action="auth.php" method="POST">
                <input type="hidden" name="register">
            <div class="two-forms">
                <div class="input-box">
                    <input type="text" class="input-field" placeholder="Firstname" id="nome" name="nome">
                    <i class="bx bx-user"></i>
                </div>
                <div class="input-box">
                    <input type="text" class="input-field" placeholder="Lastname" id="cognome" name="cognome">
                    <i class="bx bx-user"></i>
                </div>
            </div>
            <div class="input-box">
                <input type="text" class="input-field" placeholder="Email" id="mail" name="mail">
                <i class="bx bx-envelope"></i>
            </div>
            <div class="input-box">
                <input type="password" class="input-field" placeholder="Password" id="password" name="password">
                <i class="bx bx-lock-alt"></i>
            </div>
            <div class="input-box">
                <input type="submit" class="submit" value="Register" id="Invia">
            </div>
            <div class="two-col">
                <div class="one">
                    <input type="checkbox" id="terms-checkbox">
                    <label for="terms-checkbox">I agree and accept the <a href="./terms&conditions.html" class="terms-link" target="_blank" onclick="return validateTerms()">Terms & Conditions</a></label>
                </div>
            </div>
            </form>

        </div>
    </div>
</div>   
<div id="myModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <p>Devi accettare i Termini e le Condizioni per registrarti.</p>
  </div>
</div>

<script src="script.js"></script>
</body>
</html>

